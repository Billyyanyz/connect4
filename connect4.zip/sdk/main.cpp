#include "ai_client.hpp"

int main()
{
    AI_Client AI;
    AI.run();
    return 0;
}